#include<fstream>
#include<stdlib.h>
#include<time.h>
using namespace std;
int main()
{
	srand(time(NULL));
	ofstream file("100.txt");
	for(int i=0;i<200;i++)
	{
		for(int j=0;j<4;j++)
		{
			for(int k=0;k<3;k++)
			{
				file<<rand()%2;
				if(k<2)file<<" ";
			}
			file<<endl;
		}
	}
}
