#include<iostream>
#include<fstream> 
using namespace std;
const int INF=99999;          //����� 
int n=4,m=3;              //n���У�m���� 
const int N=101;
int a[N][N];int b[N][N];int c[N][N];               //cΪԭ����bΪĿ�����aΪ��ʱ�洢 
int need=0;                                  //�任���� 
void changel(int i,int j)                  //�б仯 ������i�к͵�j��
{
	int s;
	for(int k=0;k<n;k++)
	{
		s=a[k][i];
		a[k][i]=a[k][j];
		a[k][j]=s;
	}
	need++;	
} 
void changeh(int h)
{
	for(int i=0;i<m;i++)
	{
		if(a[h][i]==1)
		{
			a[h][i]=0;
		}
		else
		{
			a[h][i]=1;
		}
	}
	need++;
}
bool same(int i,int j)        //�ж�ԭ�����i�к�Ŀ������j���Ƿ���� 
{
	for(int k=0;k<n;k++)
	{
		if(a[k][i]!=b[k][j])
		return 0;
	}
	return 1;
}
int main()
{
	ifstream file("100.txt");
	ofstream output("output"); 
	for(int os=0;os<100;os++)
	{
		int ans=INF;
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<m;j++)
		{
			file>>c[i][j];
		}	
	}                                       //ԭ����c 
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<m;j++)
		{
			file>>b[i][j];
		}	
	}                                       //Ŀ�����b       
/*	for(int i=0;i<n;i++)
	{
		for(int j=0;j<m;j++)
		{
			cout<<b[i][j]<<" ";        //�鿴�ļ����Ŀ������Ƿ�����ȷ 
		}
		cout<<endl;
	 } */ 
	for(int i=0;i<n;i++)
	{
		need=0;
		for(int o=0;o<n;o++)
		{
			for(int k=0;k<m;k++)
			{
				a[o][k]=c[o][k];
			}
		}
		changel(i,0);
		for(int j=0;j<n;j++)
		{
			if(a[j][0]!=b[j][0])
			{
				changeh(j);
			}	
		}	
		bool find;
		for(int j=0;j<m;j++)
		{
			find=0;
			if(same(j,j)){
				find=1;
				continue;
			}
			for(int k=j+1;k<m;k++)
			{
				if(same(k,k)){
					find=1;
					continue;	
				}
				if(same(k,j)){
					find=1;
					changel(k,j);	
				}
			}
			if(find==0)
			{
				break;
			}
		}
		if(find==1&&need<ans)
		{
			ans=need;
		}
	}
	if(ans!=INF)
	{
		output<<ans<<endl;
		cout<<ans;	
	}
	
	else
	{
		output<<ans<<endl;
		cout<<-1;
	}
		
	}
	
} 
